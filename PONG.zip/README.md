# PONG

## Description

A game of PONG in SFML that supports 1 player mode and 2 players mode

## Controls

1. Press F to start the game
2. Press 1 or 2 to select player mode
3. For left side player, press W to move up and S to move down.
4. For right side player, press Up arrow to move up and Down arrow to move down
5. Press P to pause/unpasue the game screen
